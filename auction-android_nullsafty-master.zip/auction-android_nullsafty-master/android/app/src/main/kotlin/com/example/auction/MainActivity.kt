package com.example.auction

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
