import 'package:auction/ui/widgets/custom_background.dart';
import 'package:auction/utils/FCIStyle.dart';
import 'package:auction/utils/utils.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_html/flutter_html.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

import '../../logic/controllers/mainData_controller.dart';

class AboutUsView extends StatefulWidget  {
  const AboutUsView({Key? key}) : super(key: key);

  @override
  _AboutUsViewState createState() => _AboutUsViewState();
}

class _AboutUsViewState extends State<AboutUsView> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar:AppBar(
        backgroundColor:FCIColors.primaryColor(),
        elevation: 0,
        leading: Container(),
        bottom: PreferredSize(
          preferredSize: Size.fromHeight(ScreenUtil().setHeight(40)),
          child: Builder(builder: (context) {
            return Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                IconButton(
                  icon: Icon(
                    Icons.arrow_back_ios,
                    color: Colors.white,
                    size: ScreenUtil().setSp(25),
                  ),
                  onPressed: () {
                    Get.back();
                  },
                ),
                Text("About Us".tr,style: FCITextStyle.bold(22,color: Colors.white),),
                IconButton(
                  icon: Icon(
                    Icons.search_rounded,
                    color: Colors.white,
                    size: ScreenUtil().setSp(35),
                  ),
                  onPressed: () {

                  },
                ),
              ],
            );
          }),
        ),
      ),
      backgroundColor: FCIColors.accentColor(),
      body: Background(
          child: GetBuilder<MainDataController>(
              init: MainDataController(dataType: 'about'),
              builder: (MainDataController controller) {
                return Container(
                  margin: EdgeInsets.symmetric(horizontal: ScreenUtil().setWidth(15),
                      vertical:ScreenUtil().setHeight(20) ),
                  width: FCISize.width(context),
                  child: Card(
                    child: Padding(
                        padding: EdgeInsets.symmetric(horizontal: ScreenUtil().setWidth(10),
                            vertical:ScreenUtil().setHeight(10) ),
                        child:Center(
                          child: controller.dataLoading?Utils.loading():SingleChildScrollView(
                            child: Html(
                                data: controller.data
                            ),
                          ),
                        )
                      // Column(
                      //   children: [
                      //     controller.dataLoading?Utils.loading():
                      //     Text(controller.data)
                      //   ],
                      // ),
                    ),
                  ),
                );
            }
          )),
    );
  }
}
