import 'package:intl/intl.dart';

///***************************************
///    Api Url                           *
///***************************************
const String BaseUrl = 'http://hrms.fsdmarketing.com/api/v1/';

///***************************************
///    Google Key                        *
///***************************************
const String GOOGLEMAPKEY = 'AIzaSyAk1uY8AeObIhRtx1FaivZVDAqWq6W2gr0';

///***************************************
///    Images Url                        *
///***************************************
class FCIConstant {
  static String splashLogo = "assets/images/splash.png";
  static String logo = "assets/images/logo.png";
  static String background = "assets/images/background.png";
}

///***************************************
///    Enums                             *
///***************************************
enum AuthType { login, signUp }

enum UserType { user, service_provider }

String removeAllHtmlTags(String htmlText) {
  RegExp exp = RegExp(r"<[^>]*>", multiLine: true, caseSensitive: true);

  return htmlText
      .replaceAll(exp, '\n')
      .replaceAll('\n\n', '\n')
      .replaceAll('\n\n', '\n');
}

String convertFromStringToRange(String rangeString) {
  final value = new NumberFormat("#,###,##0", "en_US");

  return '${value.format(double.parse(rangeString))}';
}
//
// CircleAvatar buildCircleAvatarCounter(BuildContext context, int padge) {
//   return CircleAvatar(
//     backgroundColor: FCIColors.orange(),
//     child: Text('$padge',
//         style:
//             Theme.of(context).textTheme.overline.copyWith(color: Colors.white)),
//   );
// }

// enum MainScreenTaps{
//   CitiesScreen,
//   MyOrders,
//   Notifications,
//   Profile
// }
